#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/delay.h>

#define botao1 1
#define botao2 2
#define botao3 3
#define botaoup botao1
#define botaodown botao3
#define botaoM botao2
#define pinoRED 3
#define pinoGREEN 2
#define pinoBLUE 1
#define desvioMax 4
#define passo 5
#define addrRED 0x02
#define addrGREEN 0x08
#define addrBLUE 0x14
#define LCD_DATA_MASK ((1 << PD4)|(1 << PD5)|(1 << PD6)|(1 << PD7))
#define RS PD2
#define EN PD3


volatile unsigned int valorred = 0;
volatile unsigned int valorblue = 0;
volatile unsigned int valorgreen = 0;
volatile unsigned int controle = 0x01;
volatile unsigned int curRed = 0;
volatile unsigned int curBlue= 0;
volatile unsigned int curGreen=0;


///dec functions
void setup();
void setPinos();
void setInterruptions();
void setCounter();
void setup();
void updateValuesRGB(unsigned int red1, unsigned int green1, unsigned int blue1);
void loop();
void incRed();
void decRed();
void incGreen();
void decGreen();
void incBlue();
void decBlue();
void saveEEPROM(unsigned int valorREDEEPROM, unsigned int valorGREENEEPROM, unsigned int valorBLUEEEPROM);
void loadEEPROM();
void writeEEPROM(unsigned int addr, uint8_t dados);
uint8_t readEEPROM(unsigned int addr);
void pulso_enable_lcd();
void enviar_nibble_lcd(uint8_t valor);
void comando_lcd(uint8_t valor, uint8_t rs);
void inic_LCD_4bits(void);
void escreve_lcd(char *str);
ISR(PCINT1_vect);
void setup(){
    setPinos();
    setInterruptions();
    loadEEPROM();
    inic_LCD_4bits();
    updateValuesRGB(curRed,curGreen,curBlue);
}

void setPinos(){
    DDRD = 0xFE;
    DDRB |= (1<<pinoRED) | (1<<pinoGREEN) | (1<<pinoBLUE);
}

void setInterruptions(){
    PCICR = (1<<PCIE1);
    PCMSK1 = (1<<PCINT9) | (1<<PCINT10) | (1<<PCINT11);
    sei();
}
void setCounter(){
    TCCR0A |= (1<<COM0A1) | (1<<WGM10);
    TCCR0B |= (1<<WGM13) | (1<<CS12);
    TCCR1A |= (1<<COM1A1)| (1<<WGM10) | (1<<WGM10);
    TCCR1B |= (1<<WGM13) | (1<<CS12);
}

void updateValuesRGB(unsigned int red1, unsigned int green1, unsigned int blue1){
    valorred = red1;
    valorgreen = green1;
    valorblue = blue1;
}


void writeLed(){
    for(int i =0; i<valorred;i++){
        PORTB |= (1<<pinoRED);
    }
    PORTB &= ~(1<<pinoRED);
    for(int i=0; i<valorgreen; i++){
        PORTB |= (1<<pinoGREEN);
    }
    PORTB &= ~(1<<pinoGREEN);
    for(int i=0; i<valorblue; i++){
        PORTB |= (1<<pinoBLUE);
    }
    PORTB &= ~(1<<pinoBLUE);


}

void incRed(){
    if(curRed!=255){
    curRed+=passo;}
}
void decRed(){
    if(curRed!=0) {
    curRed-=passo;}
}
void incGreen(){
    if(curGreen!=255) {
    curGreen+=passo;
    }
}
void decGreen(){
    if(curGreen!=0){
    curGreen-=passo;
    }
}
void incBlue(){
    if(curBlue!=255) {
    curBlue+=passo;
    }
}
void decBlue(){
    if(curBlue!=0)
    {curBlue-=passo;}
}

ISR(PCINT1_vect){

    if(~PINC & (1<<botaoup)){
        switch (controle)
        {
        case (1<<0):  //RED
            incRed();
            break;
        case (1<<1): //GREEN
            incGreen();
        break;
        case (1<<2): //BLUE
            incBlue();
        break;
        default:
            break;
        }
    }
    else if(~PINC & (1<<botaodown)){

        switch (controle)
        {
        case (1<<0):  //RED
            decRed();
            break;
        case (1<<1): //GREEN
            decGreen();
        break;
        case (1<<2): //BLUE
            decBlue();
        break;
        default:
            break;
        }
    }
    else if(~PINC & (1<<botaoM)){
        if(controle == (1<<desvioMax)){
            controle = 0x01;
        }
        else{controle = (controle<<1);}
    }
    saveEEPROM(curRed,curGreen,curBlue);
    updateValuesRGB(curRed,curGreen,curBlue);
}


int main(){
    setup();
    loop();
    return 0;
}

void loop(){
    while(1){
    writeLed();
    escreve_lcd("JESUS CRISTO TE AMA");
    }
}

void writeEEPROM(unsigned int addr, uint8_t dados){
    while (EECR & (1 << EEPE));
    EEAR = addr;
    EEDR = dados;
    EECR |= (1 << EEMPE);
    EECR |= (1 << EEPE);
}
uint8_t readEEPROM(unsigned int addr){
    while (EECR & (1 << EEPE));

    EEAR = addr;

    EECR |= (1 << EERE);
return EEDR;
}
void saveEEPROM(unsigned int valorREDEEPROM, unsigned int valorGREENEEPROM, unsigned int valorBLUEEEPROM){
    writeEEPROM(addrRED, valorREDEEPROM);
    writeEEPROM(addrGREEN,valorGREENEEPROM);
    writeEEPROM(addrBLUE, valorBLUEEEPROM);
}
void loadEEPROM(){
    curRed = readEEPROM(addrRED);
    curGreen = readEEPROM(addrGREEN);
    curBlue = readEEPROM(addrBLUE);
}

void pulso_enable_lcd(){
    PORTD |= (1<<EN);
    _delay_us(1);
    PORTD &= ~(1<<EN);
    _delay_us(100);
}

void enviar_nibble_lcd(uint8_t valor){
    PORTD &= ~LCD_DATA_MASK;
    PORTD |= (valor<<4) & LCD_DATA_MASK;
    pulso_enable_lcd();
}

void comando_lcd(uint8_t valor, uint8_t rs){
    if(rs) PORTD |= (1<<RS);
    else PORTD &= ~(1<<RS);
    enviar_nibble_lcd(valor>>4);
    enviar_nibble_lcd(valor&0x0F);
    if(rs == 0 && valor <4) _delay_ms(2);
    else _delay_us(40);
}

void inic_LCD_4bits(void){
    _delay_ms(40);
    PORTD &= ~(1<<RS);
    enviar_nibble_lcd(0x03);
    _delay_ms(5);
    enviar_nibble_lcd(0x03);
    _delay_us(150);
    enviar_nibble_lcd(0x03);
    _delay_us(150);
    enviar_nibble_lcd(0x02);
    _delay_us(150);

    comando_lcd(0x28,0);
    comando_lcd(0x08,0);
    comando_lcd(0x01,0);
    _delay_ms(2);
    comando_lcd(0x06,0);
    comando_lcd(0x0C,0);
}

void escreve_lcd(char *str) {
    while (*str) {
        comando_lcd(*str++, 1);
    }
}
