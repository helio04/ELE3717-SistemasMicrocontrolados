#ifndef EEPROMADDR_H
#define EEPROMADDR_H



#define C0addr  0x02
#define C1addr  0x06
#define C2addr  0x0A
#define C3addr  0x0E
#define C4addr  0x12
#define C5addr  0x16
#define C6addr  0x1A
#define C7addr  0x1E
#define C8addr  0x22
#define C9addr  0x26
#define C10addr 0x2A
#define C11addr 0x2E
#define C12addr 0x32
#define C13addr 0x36
#define C14addr 0x3A
#define C15addr 0x3E


#endif